
public class JWTAuthenticationFilter extends OncePerRequestFilter {

    private JWTAuthentication jwtAuthentication = new JWTAuthentication();

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try {
            Authentication authentication = jwtAuthentication.authenticate(request).orElse(null);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            filterChain.doFilter(request, response);
        } catch (MalformedTokenException e) {
            String message = String.format("Invalid Token! Exception:%s - Message:%s", e.getClass().getSimpleName(), e.getMessage());
            notifyInvalidToken(response, message);
        } catch (ExpiredJwtException | UnsupportedJwtException |
                MalformedJwtException | SignatureException e) {
            String mensagem = String.format("Invalid JWT Token! Exception:%s - Message:%s", e.getClass().getSimpleName(), e.getMessage());
            notifyInvalidToken(response, mensagem);
        }
    }

    private void notifyInvalidToken(HttpServletResponse response, String mensagem) {
        logger.warn(mensagem);
        notifyNotAuthorized(mensagem, response);
    }

    private void notifyNotAuthorized(String message, HttpServletResponse httpResponse) {
        httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        final String wwwAuthenticateHeaderValue = String.format("%s realm=\"%s\"", TOKEN_PREFIX, message);
        httpResponse.setHeader("WWW-Authenticate", wwwAuthenticateHeaderValue);
    }
}
