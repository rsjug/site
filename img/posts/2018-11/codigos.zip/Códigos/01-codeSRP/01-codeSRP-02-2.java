
class JWTAuthentication {

    private static final String HEADER_STRING = "Authorization";
    private static final String SIGNING_KEY = "9DC71B422F372FCB276E1E6F1BBDA8BE9DE55093608BF5040450AB770E5B3A45";
    static final String TOKEN_PREFIX = "Bearer";

    Optional<Authentication> authenticate(HttpServletRequest request) throws IOException {
        String token = request.getHeader(HEADER_STRING);

        if (isBlank(token)){
            return Optional.empty();
        }

        Jws<Claims> jws = parserToken(token);
        JWTSubject subject = extractSubject(jws);

        String principal = subject.getUsername();
        Collection<GrantedAuthority> authorities = getAuthorities(subject);

        return Optional.of(new UsernamePasswordAuthenticationToken(principal, null, authorities));
    }

    private JWTSubject extractSubject(Jws<Claims> jws) throws IOException {
        final String subject = jws.getBody().getSubject();
        if (subject == null) {
            String message = "Token not contains any user information";
            throw new MalformedTokenException(message);
        }
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(subject, JWTSubject.class);
    }

    private Jws<Claims> parserToken(String token) {
        if (!token.startsWith(TOKEN_PREFIX)) {
            String message = String.format("Token not start wiht prefix '%s'", TOKEN_PREFIX);
            throw new MalformedTokenException(message);
        }

        String jwtToken = token.replace(TOKEN_PREFIX, "");
        if (isBlank(jwtToken)) {
            String message = "Token not contains JSON Web Tokens (JWT)";
            throw new MalformedTokenException(message);
        }

        return Jwts.parser().setSigningKey(SIGNING_KEY).parseClaimsJws(jwtToken);
    }

    private Collection<GrantedAuthority> getAuthorities(JWTSubject subject) {
        Function<String, GrantedAuthority> converterToGrantedAuthority = role -> (GrantedAuthority) () -> role;
        return subject.getRoles().stream().map(converterToGrantedAuthority).collect(toList());
    }
}
