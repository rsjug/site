
public class JWTAuthenticationFilter extends OncePerRequestFilter {
    
	private static final String HEADER_STRING = "Authorization";
    private static final String SIGNING_KEY = "9DC71B422F372FCB276E1E6F1BBDA8BE9DE55093608BF5040450AB770E5B3A45";
    private static final String TOKEN_PREFIX = "Bearer";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try {
            Authentication authentication = getAuthentication(request);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            filterChain.doFilter(request, response);
        } catch (MalformedTokenException e) {
            String message = String.format("Invalid Token! Exception:%s - Message:%s", e.getClass().getSimpleName(), e.getMessage());
            notifyInvalidToken(response, message);
        } catch (ExpiredJwtException | UnsupportedJwtException |
                MalformedJwtException | SignatureException e) {
            String mensagem = String.format("Invalid JWT Token! Exception:%s - Message:%s", e.getClass().getSimpleName(), e.getMessage());
            notifyInvalidToken(response, mensagem);
        }
    }

    private Authentication getAuthentication(HttpServletRequest request) throws IOException {
        String token = request.getHeader(HEADER_STRING);

        if (isBlank(token)){
            return null;
        }

        Jws<Claims> jws = parserToken(token);
        JWTSubject subject = extractSubject(jws);

        String principal = subject.getUsername();
        Function<String, GrantedAuthority> converterToGrantedAuthority = role -> (GrantedAuthority) () -> role;
        Collection<GrantedAuthority> authorities = subject.getRoles().stream().map(converterToGrantedAuthority).collect(toList());

        return new UsernamePasswordAuthenticationToken(principal, null, authorities);
    }

    private JWTSubject extractSubject(Jws<Claims> jws) throws IOException {
        final String subject = jws.getBody().getSubject();
        if (subject == null) {
            String message = "Token not contains any user information";
            throw new MalformedTokenException(message);
        }
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(subject, JWTSubject.class);
    }

    private Jws<Claims> parserToken(String token) {
        if (!token.startsWith(TOKEN_PREFIX)) {
            String message = String.format("Token not start wiht prefix '%s'", TOKEN_PREFIX);
            throw new MalformedTokenException(message);
        }

        String jwtToken = token.replace(TOKEN_PREFIX, "");
        if (isBlank(jwtToken)) {
            String message = "Token not contains JSON Web Tokens (JWT)";
            throw new MalformedTokenException(message);
        }

        return Jwts.parser().setSigningKey(SIGNING_KEY).parseClaimsJws(jwtToken);
    }

    private void notifyInvalidToken(HttpServletResponse response, String mensagem) {
        logger.warn(mensagem);
        notifyNotAuthorized(mensagem, response);
    }

    private void notifyNotAuthorized(String message, HttpServletResponse httpResponse) {
        httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        final String wwwAuthenticateHeaderValue = String.format("%s realm=\"%s\"", TOKEN_PREFIX, message);
        httpResponse.setHeader("WWW-Authenticate", wwwAuthenticateHeaderValue);
    }
}