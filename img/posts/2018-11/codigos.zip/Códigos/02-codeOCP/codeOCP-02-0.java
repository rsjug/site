@Service
public class ProjectUpdateSevice {
	
	private Logger looger = LoggerFactory.getLogger(ProjectUpdateSevice.class);

	@Transactional
	public void update(Project project) {
		final int originalNumberOfCommits = project.getNumberOfCommits();
		
		try {
			GitUpdateCommand command = getCommand(project);
			String resultMessage = command.execute();
			updateNewCommits(project, originalNumberOfCommits);
			looger.debug("UPDATE PROJECT - 'git svn fetch' command executed with sucess:", resultMessage);
		} catch (Exception exception) {
			looger.error("UPDATE PROJECT ERROR:", exception);
		}

	}
	
	private GitUpdateCommand getCommand(Project project) {
		File repositoryPath = project.getRepositoryPath();
		RepositoryType repositoryType = project.getRepositoryType();
		//ACOPLAMENTO COM O TIPO DE REPOSITÓRIO
		switch (repositoryType) {
			case GIT: {
				GitPullCommandBuilder builder = new GitPullCommandBuilder();
				return builder.build(repositoryPath);
			}
			case SVN: {
				GitSvnFetchCommandBuilder builder = new GitSvnFetchCommandBuilder();
				return builder.build(repositoryPath);
			}
			default: throw new IllegalStateException("Can not resolve type : " + repositoryType);
		}
	}

	private void updateNewCommits(Project project, final int originalNumberOfCommits) {
		final int actualNumberDeCommits = project.getNumberOfCommits();
		int newCommits = actualNumberDeCommits - originalNumberOfCommits;
		if (newCommits > 0)
			project.setNewCommits(newCommits);
		else
			project.setNewCommits(0);
	}
