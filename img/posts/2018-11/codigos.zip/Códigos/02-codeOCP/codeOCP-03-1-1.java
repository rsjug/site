public class ReviewDTO {

	private Long id;
	private String commitId;
	private String file;
	
	@NotNull
	private CodeAnalysisStatus analysisStatus;
	
	@NotBlank
	private String comment;
	
	private Long projectId;
	
	private String pageUrl;

	public ReviewDTO() {
	}

	public ReviewDTO(Review review) {
		this.id = review.getId();
		this.commitId = review.getCommitId();
		this.file = review.getFile().getPath();
		this.analysisStatus = review.getAnalysisStatus();
		this.comment = review.getComment();
		this.projectId review.getProject().getId();
	}

	//GETTERS AND SETTERS
}