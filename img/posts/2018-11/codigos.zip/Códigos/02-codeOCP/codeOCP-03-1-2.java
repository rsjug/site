@Controller
@RequestMapping("/projects")
public class AddReview {
	
	@Autowired
	private LoggedUser loggedUser;
	@Autowired
	private ReviewManipulationService service;
	@Autowired
	private ListReviewsService fileReviews;
	
	@RequestMapping(value="/review", method=GET)
    public ModelAndView getForm(@ModelAttribute ReviewDTO fileReview) {
		ModelAndView modelAndView = new ModelAndView("fragments/formAddReview :: formAddReview");
		return modelAndView;
	}
	
	@RequestMapping(value="/review", method=POST)
    public ModelAndView addReview(@Valid @ModelAttribute ReviewDTO form, BindingResult validateResult, HttpServletRequest request) {
		if (validateResult.hasErrors())
			return getForm(form);

		insertReview(form);
		
		ModelAndView modelAndView = new ModelAndView("fragments/reviews :: reviews");
		modelAndView.addObject("reviews", listReviews(form));
		
		return modelAndView;
	}
	// OUTROS MÉTODOS
}
