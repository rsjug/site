@Entity
public class Review {

	@Id @GeneratedValue(strategy=AUTO)
	private Long id = 0L;
	@Version
	private Integer version;
	@OneToOne @JoinColumn
	private SystemUser author;
	@OneToOne @JoinColumn
	private Project project;
	private String commitId;
	@Column(length=2048) @Convert(converter=FileConverter.class)
	private File file;
	@Convert(converter=LocalDateTimeConverter.class)
	private LocalDateTime dateTime;
	@Lob
	private String comment;
	@Convert(converter=LocalDateTimeConverter.class)
	private LocalDateTime lastEdition;
	@OneToMany(cascade=ALL) @JoinColumn
	private List<ReplyReview> replies = new ArrayList<>();
	private CodeAnalysisStatus analysisStatus;
	
	//GETTERS AND SETTERS
}
