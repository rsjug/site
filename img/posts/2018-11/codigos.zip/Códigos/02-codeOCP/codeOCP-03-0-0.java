@Entity
public class Review {

	@Id @GeneratedValue(strategy=AUTO)
	private Long id = 0L;
	@Version
	private Integer version;
	@OneToOne @JoinColumn
	private SystemUser author;
	@OneToOne @JoinColumn
	private Project project;
	private String commitId;
	@Column(length=2048) @Convert(converter=FileConverter.class)
	private File file;
	@Convert(converter=LocalDateTimeConverter.class)
	private LocalDateTime dateTime;
	@Convert(converter=LocalDateTimeConverter.class)
	private LocalDateTime lastEdition;
	@OneToMany(cascade=ALL) @JoinColumn
	private List<ReplyReview> replies = new ArrayList<>();
	
	@NotNull
	private CodeAnalysisStatus analysisStatus;
	
	@Lob
	@NotBlank
	private String comment;

	@Transient
	private String pageUrl;
	
	//GETTERS AND SETTERS
}