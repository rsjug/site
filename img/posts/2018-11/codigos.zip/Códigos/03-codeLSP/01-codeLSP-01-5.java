
/**************************************************************************************************
  Tem um ou é Um? 
  O que acontece se um Cliente for pessoa jurídica??? Ou um Fornecedor for uma pessoa física???
**************************************************************************************************/

public class Cliente extends CadastroDePessoaFisica {
	//Implementação
}

public class Fornecedor extends CadastroDePessoaJuridica {
	//Implementação
}


/*************    Priorize a composição!!!!   ********************************/

public class Cliente {

    private Cadastro cadastro;
	//Outros Campos

    public Cadastro getCadastro() {
        return cadastro;
    }

    public void setCadastro(Cadastro cadastro) {
        if (cadastro == null)
            throw new IllegalArgumentException("O campo 'cadastro não pode ser nulo'");
        this.cadastro = cadastro;
    }
	//Outros métodos
}

public class Fornecedor {

    private Cadastro cadastro;
	//Outros Campos

    public Cadastro getCadastro() {
        return cadastro;
    }

    public void setCadastro(Cadastro cadastro) {
        if (cadastro == null)
            throw new IllegalArgumentException("O campo 'cadastro não pode ser nulo'");
        this.cadastro = cadastro;
    }
	//Outros métodos
}
