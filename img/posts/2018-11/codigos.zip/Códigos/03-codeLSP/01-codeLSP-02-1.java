@RestController
public class BaseController {

	protected ResponseEntity<?> get(String endpointCadastrado) {
		//Implementação
	}
	
	//Outros métodos
}
