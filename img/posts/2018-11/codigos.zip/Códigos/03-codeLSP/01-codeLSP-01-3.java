
public class ServicoDeCadastro {

    public void alterarEndereco(Cadastro cadastro, Endereco novoEndereco) {
        //O que acontece se novoEndereco for nulo?
        //Deveria gerar uma exeção pois é isso que classe Cadastro exige então é obrigação não passar um valor não nulo!!!
        //Embora não quebre a pre-condição e esteja correto fica muito confuso
        cadastro.setEndereco(novoEndereco);
    }

    public void alterarEndereco(CadastroDePessoaFisica cadastro, Endereco novoEndereco) {
        //O que acontece se novoEndereco for nulo?
        //Nada, está correto pois estou trabalhando com a classe CadastroDePessoaFisica!
        cadastro.setEndereco(novoEndereco);
    }

    public void alterarTelefone(Cadastro cadastro, Telefone novoTelefone) {
        //O que acontece se novoTelefone for nulo?
        //Não poderia gerar uma exeção já que a classe Cadastro não exige um valor não nulo
        cadastro.setTelefone(novoTelefone);
    }
}
