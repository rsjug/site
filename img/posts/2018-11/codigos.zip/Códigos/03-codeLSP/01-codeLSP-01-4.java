
public class ServicoDeEtiquetas {

    public String etiquetaDeEndereco(Cadastro cadastro) {
        //O que acontece 'getEndereco' retornar nulo?
        //Não poderia pois em Cadastro não retorna um Optional,
        //então embora não quebre a pré-condição ao tornar nulo em CadastroDePessoaFisica quebra a pós-condição
        Endereco endereco = cadastro.getEndereco();
        StringBuilder builder = new StringBuilder();
        builder.append(endereco.getRua()).append(" ").append(endereco.getNumero()).append("\n");
        builder.append(endereco.getCidade()).append(" - ").append(endereco.getEstado()).append("\n");
        builder.append(endereco.getCep());

        return builder.toString();
    }
}
