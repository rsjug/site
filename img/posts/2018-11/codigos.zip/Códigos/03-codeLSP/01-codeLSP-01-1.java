
public class CadastroDePessoaFisica extends Cadastro {

    private String cpf;

    @Override
    public String getIdentificador() {
        return cpf;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        if (cpfInvalido(cpf))
            throw new IllegalArgumentException("CPF inválido");
        this.cpf = cpf;
    }

    @Override
    public void setEndereco(Endereco endereco) {
        //Endereço não podia ser nulo, então respeita a pré-condição da classe
        this.endereco = endereco;
    }

    private boolean cpfInvalido(String cpf) {
        return false;
    }
}