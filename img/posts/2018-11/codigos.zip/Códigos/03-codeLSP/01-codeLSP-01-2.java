
public class CadastroDePessoaJuridica extends Cadastro {

    private String cnpj;

    @Override
    public String getIdentificador() {
        return cnpj;
    }

    @Override
    public void setTelefone(Telefone telefone) {
        //Telefone podia ser nulo, agora não pode não respeita a pre-condição da classe
        if (telefone == null)
            throw new IllegalArgumentException("O campo 'telefone' não pode ser nulo");
        this.telefone = telefone;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cpf) {
        if (cnpjInvalido(cpf))
            throw new IllegalArgumentException("CNPJ inválido");
        this.cnpj = cpf;
    }

    private boolean cnpjInvalido(String cpf) {
        return false;
    }
}