public abstract class Cadastro {

    private String nome;

    protected Endereco endereco;

    protected Telefone telefone;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (isBlank(nome))
            throw new IllegalArgumentException("O parâmetro 'nome' não pode ser nulo");
        this.nome = nome;
    }

    public abstract String getIdentificador();

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        if (endereco == null)
            throw new IllegalArgumentException("O campo 'endereço' não pode ser nulo");
        this.endereco = endereco;
    }

    public Optional<Telefone> getTelefone() {
        return Optional.ofNullable(telefone);
    }

    public void setTelefone(Telefone telefone) {
        this.telefone = telefone;
    }
}
