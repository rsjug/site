@RestController
@RequestMapping("/cadastro")
public class CadastroController extends BaseController {

    private String endpointCadastro;

    public OpenApi(@Value("teste") String endpointCadastro) {
        this.endpointCadastro = endpointCadastro;
    }


	@GetMapping("/all")
	public ResponseEntity<List<CadastroDTO>> listarTodos() {
		return (List<CadastroDTO>) this.get(endpointCadastro)
	}
	
	//Outros métodos
}
