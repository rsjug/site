public class Celular implements Telefone {

    private String ddi;
    private String ddd;
    private String numero;

    public Celular(String ddd, String numero) {
        setDDD(ddd);
        setNumero(numero);
    }

	
    @Override
    public Optional<String> getDDI() {
        return Optional.of(ddi);
    }

    @Override
    public void setDDI(String ddi) {
        if (isNotBlank(ddi)) {
            validateDDI(ddi);
            this.ddi = ddi;
        } else
            this.ddi = ddi;
    }

    // demais métodos
}
