public class Celular implements Telefone {

    private String ddi;
    private String ddd;
    private String numero;

    public Celular(String ddd, String numero) {
        setDDD(ddd);
        setNumero(numero);
    }
	
    @Override
    public String getDDI() {
        return ddi;
    }

    @Override
    public void setDDI(String ddi) {
        if (StringUtils.isBlank(ddi))
            this.ddi = "+55";
        else {
            validateDDI(ddi);
            this.ddi = ddi;
        }
    }

    // demais métodos
}

public class Telefone implements Telefone {

    private String ddi;
    private String ddd;
    private String numero;

    public Telefone(String ddd, String numero) {
        setDDD(ddd);
        setNumero(numero);
    }
	
    @Override
    public String getDDI() {
        return ddi;
    }

    @Override
    public void setDDI(String ddi) {
        if (StringUtils.isBlank(ddi))
            this.ddi = "+55";
        else {
            validateDDI(ddi);
            this.ddi = ddi;
        }
    }

    // demais métodos
}
