
public interface Telefone {

    default String ddi(){
        return "+55";
    }

    String ddd();
    String numero();
}

@Embeddable
public class Celular implements Telefone {

    private String ddd;
    private String numero;

    public Celular(String ddd, String numero) {
        validateDDD(ddd);
        validateNumero(numero);
        this.ddd = ddd;
        this.numero = numero;
    }

    @Override
    public String ddd() {
        return ddd;
    }

    @Override
    public String numero() {
        return numero;
    }
	//demais métodos
}

@Embeddable
public class Fixo implements Telefone {

    private String ddd;
    private String numero;

    public Celular(String ddd, String numero) {
        validateDDD(ddd);
        validateNumero(numero);
        this.ddd = ddd;
        this.numero = numero;
    }

    @Override
    public String ddd() {
        return ddd;
    }

    @Override
    public String numero() {
        return numero;
    }
	//demais métodos
}
