/*
	Parece uma interface simples e bem definida não é?
*/

public interface Telefone {

    String getDDI();
    void setDDI(String ddi);

    String getDDD();
    void setDDD(String ddd);

    String getNumero();
    void setNumero(String numero);
}
