@Service
public class ServicoDeCadastro {

    private RepositoryCadastro repository;

    @Autowired
    public ServicoDeCadastro(RepositoryCadastro repository) {
        this.repository = repository;
    }
    
    public void alterarCelular(long idCadastro, String ddd, String numero) {
        Cadastro cadastro = repository.findById(idCadastro);
        cadastro.setCelular(new Celular(ddd, numero));
    }
}