
/********** Inversão de controle com Factories!!! *******************/

//Enums são boas factories
public enum RepositoryType {
	GIT("Git", new GitPullCommandBuilder()), 
	SVN("Svn", new GitSvnFetchCommandBuilder());

	private String description;
	private GitUpdateCommandBuilder gitUpdateCommandBuilder;
	
	RepositoryType(String description, GitUpdateCommandBuilder gitUpdateCommandBuilder) {
		this.description = description;
		this.gitUpdateCommandBuilder = gitUpdateCommandBuilder;
	}

	public String getDescription() {
		return description;
	}

	public GitUpdateCommandBuilder getGitUpdateCommandBuilder() {
		return gitUpdateCommandBuilder;
	}
}

@Service
public class ProjectUpdateSevice {
	
	//LoggerFactory, outro bom exemplo
	private Logger looger = LoggerFactory.getLogger(ProjectUpdateSevice.class);

	//... Outros métodos
	
	private GitUpdateCommand getCommand(Project project) {
		File repositoryPath = project.getRepositoryPath();
		//Aqui também utilizamos uma factory, um pouco diferente
		RepositoryType repositoryType = project.getRepositoryType();
		GitUpdateCommandBuilder builder = repositoryType.getGitUpdateCommandBuilder();
		return builder.build(repositoryPath);
	}
}
