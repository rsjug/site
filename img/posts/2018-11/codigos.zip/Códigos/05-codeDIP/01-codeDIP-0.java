@Service
public class ProjectManipulationService {

	private ProjectRepository repository;

	@Autowired
	public ProjectManipulationService(ProjectRepository repository) {
		this.repository = Objects.requireNonNull(repository, "The field 'repository' can not be null");
	}

	@Transactional
	public Project removeProject(Long projectId) {
		Project project = repository.findProjectBy(projectId);
		project.remove();
		return project;
	}

	//Outros métodos
}
