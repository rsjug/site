@Service
public class ProjectManipulationService {

	@Autowired
	private ProjectRepository repository;

	@Transactional
	public Project removeProject(Long projectId) {
		Project project = repository.findProjectBy(projectId);
		project.remove();
		return project;
	}

	//Outros métodos
}
