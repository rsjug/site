
/********** Injenção de dependencias sem anotações !!! *******************/

@Component
@Scope("singleton")
public class ContainerFactory implements ApplicationContextAware {

	private static ApplicationContext context;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		context = applicationContext;
	}

	public static <T> T get(Class<T> requiredType) {
		return context.getBean(requiredType);
	}

}

//******* Usando de uma classe um object value, mas poderia ser qualquer objeto!!!

@Embeddable
public class Email {

	//... outro métodos

	public boolean inUse() {
		SystemUserRepository repository = ContainerFactory.get(SystemUserRepository.class);
		return repository.emailInUse(this);
	}

	public boolean isOfTheUserWith(Long id) {
		if (id == null)
			return false;
		
		SystemUserRepository repository = ContainerFactory.get(SystemUserRepository.class);
		Long idFound = repository.findIdUserBy(this);
		
		return id.equals(idFound);
	}
	
	//... outro métodos
}

//**** Criando uma regra usando o e-mail!!!! ****

public class RuleEmailCanNotBeInUseByAnotherUser {

	private Email email;
	private long userId;
	
	public RuleEmailCanNotBeInUseByAnotherUser(Email email, long userId) {
		validate(email);
			
		this.email = email;
		this.userId = userId;
	}

	public boolean inAccord() {
		boolean emailNoBeInUse = !email.inUse();
		boolean emailIsOfTheUser = email.isOfTheUserWith(userId);
		
		return emailNoBeInUse || emailIsOfTheUser;
	}

	public boolean notInAccord() {
		return !inAccord();
	}

	private void validate(Email email) {
		if (email == null) {
			throw new IllegalArgumentException(ExceptionsMessages.theParameterCanNotBeNull("email"));
		}
	}
}

//**** Usando a regra dentro de uma entidade! ****

@Entity
public class SystemUser {

	//...Campos e outros métodos

	public void setEmail(Email email) {
		validateState();
		validate(email);		
		this.email = email;
	}

	private void validate(Email email) {
		if (email == null)
			throw new IllegalArgumentException(ExceptionsMessages.theParameterCanNotBeNull("email"));
		
		RuleEmailCanNotBeInUseByAnotherUser rule = new RuleEmailCanNotBeInUseByAnotherUser(email, id);
		
		if (rule.notInAccord())
			throw new IllegalArgumentException(ExceptionsMessages.theParameterCanNotBeInUse("email"));
	}
	
	private void validateState() {
		if (removed)
			throw new IllegalStateException(ExceptionsMessages.canNotEditARemovedUser());
	}
}


//**** Usando a regra para validar DTOs ****

//Annotation 
@Constraint(validatedBy=EmailCanNotBeInUseByAnotherUserValidator.class)
@Target(TYPE)
@Retention(RUNTIME)
public @interface EmailCanNotBeInUseByAnotherUser {
	  String message() default "";
	  Class<?>[] groups() default { };
	  Class<? extends Payload>[] payload() default { };
}

//Validator
public class EmailCanNotBeInUseByAnotherUserValidator implements ConstraintValidator<EmailCanNotBeInUseByAnotherUser, UserFormEdit> {

	@Override
	public void initialize(EmailCanNotBeInUseByAnotherUser constraintAnnotation) {
	}

	@Override
	public boolean isValid(UserFormEdit user, ConstraintValidatorContext context) {
		Email email;

		try {
			email = new Email(user.getEmailAddress());
		} catch (IllegalArgumentException e) {
			return true;
		}
		
		long userId = user.getId();
		
		// Usando a regra!!!
		RuleEmailCanNotBeInUseByAnotherUser rule = new RuleEmailCanNotBeInUseByAnotherUser(email, userId);
		
		return rule.inAccord();
	}
}

// DTO com a validação
@EmailCanNotBeInUseByAnotherUser
public class UserDTO {

	private Long id;
	
	@NotBlank
	private String name;
	
	@NotBlank @Email
	private String emailAddress;

	private boolean isAdmin;

	//Outros métodos
}

